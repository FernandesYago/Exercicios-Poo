public interface Calcular {
        double calcular(double num1, double num2);

}
