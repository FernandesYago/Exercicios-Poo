public class Main {
    public static void main(String[] args) {
        // Exemplo de Pessoa Física
        PessoasFisicas pessoaFisica = new PessoasFisicas(
                "123.456.789-01", // CPF
                "123456789",      // RG
                "João da Silva",  // Nome
                "30",             // Idade
                "Mestrado",       // Titulação
                "Rua A",          // Logradouro
                "123",            // Número
                "Bairro B",       // Bairro
                "Cidade C",       // Cidade
                "UF",             // UF
                "987654321",      // Telefone
                "joao@email.com", // Email
                "Matemática"      // Disciplina Ministrada
        );

        // Exemplo de Pessoa Jurídica
        PessoasJuridicas pessoaJuridica = new PessoasJuridicas(
                "Rua X",              // Logradouro
                "456",                // Número
                "Bairro Y",           // Bairro
                "Cidade Z",           // Cidade
                "UF",                 // UF
                "987654321",          // Telefone
                "empresa@email.com",  // Email
                "Computação",         // Disciplina Ministrada
                "Razão Social XYZ",   // Razão Social
                "Nome Fantasia XYZ",  // Nome Fantasia
                "123456",             // Inscrição Municipal
                "789012",             // Inscrição Estadual
                "9876543210001",      // CNPJ
                "www.empresa.com"     // Website
        );

        // Imprimir informações da Pessoa Física
        System.out.println("Informações da Pessoa Física:");
        System.out.println("Nome: " + pessoaFisica.getNome());
        System.out.println("CPF: " + pessoaFisica.getCpf());
        System.out.println("Idade: " + pessoaFisica.getIdade());
        System.out.println("Titulação: " + pessoaFisica.getTitulação());
        System.out.println();

        // Imprimir informações da Pessoa Jurídica
        System.out.println("Informações da Pessoa Jurídica:");
        System.out.println("Razão Social: " + pessoaJuridica.getRazaoSocial());
        System.out.println("CNPJ: " + pessoaJuridica.getCnpj());
        System.out.println("Inscrição Estadual: " + pessoaJuridica.getInscricaoEstadual());
        System.out.println("Website: " + pessoaJuridica.getWebsite());
    }
}
