public interface CalcularNotas {
     String notaMaxima();
     String notaMedia();
     String notaMinima();

     String obterConceito(double nota);
}
